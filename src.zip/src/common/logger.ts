import debug from "debug";

export const debugLogger: debug.IDebugger = debug("app");

